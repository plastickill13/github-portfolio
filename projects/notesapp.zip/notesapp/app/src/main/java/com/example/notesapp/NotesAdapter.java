package com.example.notesapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class NotesAdapter extends android.widget.ArrayAdapter<Note> {
    private Context context;
    private ArrayList<Note> notes;

    public NotesAdapter(@NonNull Context context, @NonNull ArrayList<Note> notes) {
        super(context, R.layout.note_item, notes);
        this.context = context;
        this.notes = notes;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.note_item, parent, false);
        }

        Note note = notes.get(position);

        TextView tvTitle = convertView.findViewById(R.id.tvNoteTitle);
        TextView tvContent = convertView.findViewById(R.id.tvNoteContent);

        tvTitle.setText(note.getTitle());
        tvContent.setText(note.getContent());

        return convertView;
    }
}
