package com.example.notesapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class NotesActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_EDIT_NOTE = 1; // Define a request code
    Button btnAddNote, btnLogout;
    ListView lvNotes;
    ArrayList<Note> notesList;
    NotesAdapter notesAdapter;
    APIHelper apiHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        btnAddNote = findViewById(R.id.btnAddNote);
        btnLogout = findViewById(R.id.btnLogout);  // Logout button
        lvNotes = findViewById(R.id.lvNotes);

        notesList = new ArrayList<>();
        notesAdapter = new NotesAdapter(this, notesList);
        lvNotes.setAdapter(notesAdapter);

        apiHelper = new APIHelper(this);

        btnAddNote.setOnClickListener(v -> {
            Intent intent = new Intent(NotesActivity.this, EditNoteActivity.class);
            intent.putExtra("action", "add");
            startActivityForResult(intent, REQUEST_CODE_EDIT_NOTE); // Start EditNoteActivity for result
        });

        btnLogout.setOnClickListener(v -> {
            logout();
        });

        lvNotes.setOnItemClickListener((parent, view, position, id) -> {
            Note selectedNote = notesList.get(position);
            showUpdateOrDeleteDialog(selectedNote);
        });

        loadNotes();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes(); // Reload notes when returning to this activity
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_EDIT_NOTE && resultCode == RESULT_OK) {
            loadNotes(); // Reload notes when returning from EditNoteActivity
        }
    }

    private void loadNotes() {
        String userId = getUserIdFromPreferences();
        if (userId != null) {
            apiHelper.fetchNotes(userId, notesAdapter, notesList);
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            redirectToLogin();
        }
    }

    private String getUserIdFromPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        return sharedPreferences.getString("user_id", null);
    }

    private void redirectToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void logout() {
        // Clear user preferences (logout)
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("user_id"); // Remove the saved user ID
        editor.apply(); // Apply the changes

        // Show a message and redirect to the login page
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        redirectToLogin();
    }

    private void showUpdateOrDeleteDialog(Note selectedNote) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update or Delete this note")
                .setItems(new CharSequence[]{"Update", "Delete"}, (dialog, which) -> {
                    if (which == 0) {
                        // "Update" selected, go to EditNoteActivity
                        Intent intent = new Intent(NotesActivity.this, EditNoteActivity.class);
                        intent.putExtra("action", "edit");
                        intent.putExtra("note_id", selectedNote.getId());
                        intent.putExtra("note_title", selectedNote.getTitle());
                        intent.putExtra("note_content", selectedNote.getContent());
                        startActivityForResult(intent, REQUEST_CODE_EDIT_NOTE); // Start EditNoteActivity for result
                    } else if (which == 1) {
                        // "Delete" selected, show confirmation dialog
                        showDeleteConfirmationDialog(selectedNote);
                    }
                })
                .show();
    }

    private void showDeleteConfirmationDialog(Note selectedNote) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Are you sure you want to delete this note?")
                .setMessage("This action cannot be undone.")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Delete the note
                    apiHelper.deleteNote(selectedNote.getId(), new APIHelper.NoteDeleteCallback() {
                        @Override
                        public void onNoteDeleted() {
                            Toast.makeText(NotesActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
                            loadNotes(); // Reload notes after deletion
                        }

                        @Override
                        public void onError(String error) {
                            Toast.makeText(NotesActivity.this, "Error deleting note: " + error, Toast.LENGTH_SHORT).show();
                        }
                    });
                })
                .setNegativeButton("No", (dialog, which) -> {
                    // Exit the dialog, no action needed
                    dialog.dismiss();
                })
                .show();
    }
}
