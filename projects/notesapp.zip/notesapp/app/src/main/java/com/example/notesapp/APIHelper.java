package com.example.notesapp;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class APIHelper {
    private Context context;
    private RequestQueue requestQueue;

    public APIHelper(Context context) {
        this.context = context;
        this.requestQueue = Volley.newRequestQueue(context);
    }

    public void login(String username, String password, final LoginCallback callback) {
        String url = "http://ipaddress/notesphp/login.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            String userId = jsonObject.getString("user_id");
                            callback.onSuccess(userId);
                        } else {
                            callback.onSuccess(null);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callback.onSuccess(null);
                    }
                },
                error -> {
                    error.printStackTrace();
                    callback.onSuccess(null);
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };

        requestQueue.add(request);
    }

    public void fetchNotes(String userId, NotesAdapter adapter, ArrayList<Note> notesList) {
        String url = "http://ipaddress/notesphp/fetch_notes.php?user_id=" + userId;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    notesList.clear();
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject noteObject = response.getJSONObject(i);
                            String id = noteObject.getString("id");
                            String title = noteObject.getString("title");
                            String content = noteObject.getString("content");
                            notesList.add(new Note(id, title, content));
                        }
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(context, "Error parsing notes", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(context, "Failed to fetch notes", Toast.LENGTH_SHORT).show();
                });

        requestQueue.add(request);
    }

    public void saveOrUpdateNote(String url, Map<String, String> params, String successMessage) {
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            new Handler(Looper.getMainLooper()).post(() ->
                                    Toast.makeText(context, successMessage, Toast.LENGTH_SHORT).show());
                        } else {
                            Toast.makeText(context, "Failed to save note", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(context, "Error saving note", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(context, "Failed to save note", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };

        requestQueue.add(request);
    }

    public void deleteNote(String noteId, NoteDeleteCallback callback) {
        String url = "http://ipaddress/notesphp/delete_note.php";

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.getBoolean("success")) {
                            callback.onNoteDeleted();
                        } else {
                            callback.onError("Failed to delete note");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callback.onError("Error deleting note");
                    }
                },
                error -> {
                    error.printStackTrace();
                    callback.onError("Failed to delete note");
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("note_id", noteId);
                return params;
            }
        };

        requestQueue.add(request);
    }

    public interface LoginCallback {
        void onSuccess(String userId);
    }

    public interface NoteDeleteCallback {
        void onNoteDeleted();
        void onError(String error);
    }
}
