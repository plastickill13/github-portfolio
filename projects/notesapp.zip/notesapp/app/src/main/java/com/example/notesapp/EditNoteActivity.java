package com.example.notesapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class EditNoteActivity extends AppCompatActivity {
    EditText etNoteTitle, etNoteContent;
    Button btnSaveNote;
    String action, noteId;
    APIHelper apiHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        etNoteTitle = findViewById(R.id.etNoteTitle);
        etNoteContent = findViewById(R.id.etNoteContent);
        btnSaveNote = findViewById(R.id.btnSaveNote);

        apiHelper = new APIHelper(this);

        action = getIntent().getStringExtra("action");
        if (action.equals("edit")) {
            noteId = getIntent().getStringExtra("note_id");
            etNoteTitle.setText(getIntent().getStringExtra("note_title"));
            etNoteContent.setText(getIntent().getStringExtra("note_content"));
        }

        btnSaveNote.setOnClickListener(v -> {
            String title = etNoteTitle.getText().toString().trim();
            String content = etNoteContent.getText().toString().trim();

            if (!title.isEmpty() && !content.isEmpty()) {
                // Check if the content contains a solvable equation
                if (isEquation(content)) {
                    // Solve the equation
                    String result = solveEquation(content);
                    // Update the content with the result
                    etNoteContent.setText(result);
                    content = result; // Update content to the solved equation result
                }

                if (action.equals("add")) {
                    saveNoteToServer(title, content);
                } else if (action.equals("edit")) {
                    updateNoteToServer(noteId, title, content);
                }
            } else {
                Toast.makeText(EditNoteActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isEquation(String content) {
        // A simple check to see if the content looks like an equation (contains '=' or is a valid math expression)
        return content.contains("=") || content.matches(".*[0-9]+.*");
    }

    private String solveEquation(String equation) {
        try {
            // Create a Context to evaluate the equation
            Context context = Context.enter();
            context.setOptimizationLevel(-1); // Disable optimizations for better debugging

            // Create a scope to evaluate the equation
            Scriptable scope = context.initStandardObjects();

            // Evaluate the equation
            Object result = context.evaluateString(scope, equation, "<cmd>", 1, null);

            // Convert result to string and return
            return Context.toString(result);
        } catch (Exception e) {
            return "Invalid equation";
        } finally {
            Context.exit(); // Ensure to exit the context
        }
    }

    private void saveNoteToServer(String title, String content) {
        String userId = getUserIdFromPreferences();
        if (userId != null) {
            HashMap<String, String> params = new HashMap<>();
            params.put("user_id", userId);
            params.put("title", title);
            params.put("content", content);

            apiHelper.saveOrUpdateNote("http://ipaddress/notesphp/save_note.php", params, "Note saved successfully!");

            setResult(RESULT_OK); // Indicate success and request NotesActivity to reload notes
            finish(); // Return to NotesActivity
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateNoteToServer(String noteId, String title, String content) {
        String userId = getUserIdFromPreferences();
        if (userId != null) {
            HashMap<String, String> params = new HashMap<>();
            params.put("note_id", noteId);
            params.put("user_id", userId);
            params.put("title", title);
            params.put("content", content);

            apiHelper.saveOrUpdateNote("http://ipaddress/notesphp/edit_note.php", params, "Note updated successfully!");

            setResult(RESULT_OK); // Indicate success and request NotesActivity to reload notes
            finish(); // Return to NotesActivity
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }

    private String getUserIdFromPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        return sharedPreferences.getString("user_id", null);
    }
}
