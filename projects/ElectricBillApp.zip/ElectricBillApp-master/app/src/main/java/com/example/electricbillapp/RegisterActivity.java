package com.example.electricbillapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword;
    private Button btnRegister;

    private static final String REGISTER_URL = "http://10.159.247.233/electricbillapp/insert_admin.php";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(view -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String password = etPassword.getText().toString();
            // IF ANY TEXT FIELD IS EMPTY, THEN SHOW TOAST AND RETURN
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }
            // IF NAME IS NOT VALID, THEN SHOW TOAST AND RETURN
            if (!isValidName(name)) {
                Toast.makeText(RegisterActivity.this, "Please enter a valid name (letters and spaces only)", Toast.LENGTH_SHORT).show();
                return;
            }
            // IF EMAIL IS NOT VALID, THEN SHOW TOAST AND RETURN
            if (!isValidEmail(email)) {
                Toast.makeText(RegisterActivity.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                return;
            }
            // IF PASSWORD IS NOT VALID, THEN SHOW TOAST AND RETURN
            registerAdmin(name, email, password);
        });
    }
        // REGISTER ADMIN METHOD
    private void registerAdmin(String name, String email, String password) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                response -> {
                    // IF RESPONSE IS SUCCESS, THEN SHOW TOAST AND INTENT TO VIEW ADMIN ACTIVITY
                    if (response.trim().equalsIgnoreCase("success")) {
                        Toast.makeText(RegisterActivity.this, "Registration successful! Welcome, " + name, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegisterActivity.this, viewadminactivity.class);
                        startActivity(intent);
                        finish(); // Go back to the previous activity
                        // IF EMAIL IS ALREADY REGISTERED, THEN SHOW TOAST
                    } else if (response.trim().equalsIgnoreCase("email_exists")) {
                        Toast.makeText(RegisterActivity.this, "Email is already registered. Please use a different email.", Toast.LENGTH_SHORT).show();
                    }
                    // IF ERROR, THEN SHOW TOAST
                     else {
                        Toast.makeText(RegisterActivity.this, "Error: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error ->
                // IF ERROR, THEN LOG ERROR AND SHOW TOAST
                 {
                    Log.e("RegisterError", "Error registering admin: " + error.getMessage());
                    Toast.makeText(RegisterActivity.this, "Error registering admin: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            // GET PARAMS METHOD
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("admin_name", name);
                params.put("admin_email", email);
                params.put("admin_password", password);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }
    // VALIDATE EMAIL METHOD
    private boolean isValidEmail(String email) {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        return email.matches(emailPattern);
    }
    // VALIDATE NAME METHOD
    private boolean isValidName(String name) {
        String namePattern = "^[a-zA-Z\\s]+$"; // Allows letters and spaces only
        return name.matches(namePattern);
    }
}
