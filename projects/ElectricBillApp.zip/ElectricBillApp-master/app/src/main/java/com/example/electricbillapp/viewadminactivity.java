package com.example.electricbillapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class viewadminactivity extends AppCompatActivity {

    private TableLayout tableLayout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewadminactivity);
        tableLayout = findViewById(R.id.tableLayout);
        fetchAdminData();

        // Back button
        Button buttonBack = findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(view -> {
            Intent intent = new Intent(viewadminactivity.this, ChiefAdminActivity.class);
            startActivity(intent);
            finish();
        });

        findViewById(R.id.AddAdminButton).setOnClickListener(view -> {
            // Handle button click to add admin account
            Intent intent = new Intent(viewadminactivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }



    // Fetch data from PHP script
    private void fetchAdminData() {
        String url = "http://10.159.247.233/electricbillapp/view_admin.php";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONArray adminArray = new JSONArray(response);
                        for (int i = 0; i < adminArray.length(); i++) {
                            JSONObject admin = adminArray.getJSONObject(i);
                            String adminId = admin.getString("admin_id");
                            String adminName = admin.getString("admin_name");
                            String adminEmail = admin.getString("admin_email");
                            addRowToTable(adminId, adminName, adminEmail);
                        }
                    } catch (JSONException e) {
                        Toast.makeText(viewadminactivity.this, "Error parsing admin data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(viewadminactivity.this, "Error fetching admin data: " + error.getMessage(), Toast.LENGTH_SHORT).show());

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    // Add a row to the table
    private void addRowToTable(String adminId, String adminName, String adminEmail) {
        TableRow tableRow = new TableRow(this);

        // Set alternating background colors for rows
        int rowIndex = tableLayout.getChildCount(); // Get the current row index
        if (rowIndex % 2 == 0) {
            tableRow.setBackgroundColor(getResources().getColor(android.R.color.white)); // White background for even rows
        } else {
            tableRow.setBackgroundColor(getResources().getColor(android.R.color.darker_gray)); // Gray background for odd rows
        }

        TextView tvAdminId = createTextView(adminId);
        TextView tvAdminName = createTextView(adminName);
        TextView tvAdminEmail = createTextView(adminEmail);

        tableRow.addView(tvAdminId);
        tableRow.addView(tvAdminName);
        tableRow.addView(tvAdminEmail);

        // Set long click listener for the row
        tableRow.setOnLongClickListener(view -> {
            showUpdateDialog(adminId, adminName);
            return true;
        });

        tableLayout.addView(tableRow);
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(10, 10, 10, 10);
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(14);
        textView.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT
        ));
        return textView;
    }

    // Method to show the UpdateAdminActivity
    private void showUpdateDialog(String adminId, String adminName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Admin Account");
        builder.setMessage("Do you want to update this admin account?\n\nName: " + adminName);

        builder.setPositiveButton("Yes", (dialog, which) -> {
            // Navigate to an update activity or handle the update logic
            Intent intent = new Intent(viewadminactivity.this, UpdateAdminActivity.class);
            intent.putExtra("admin_id", adminId);
            startActivity(intent);
        });

        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
