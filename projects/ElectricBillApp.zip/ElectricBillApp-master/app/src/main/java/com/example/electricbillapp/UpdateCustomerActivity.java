package com.example.electricbillapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UpdateCustomerActivity extends AppCompatActivity {
    private EditText editTextName, editTextAddress, editTextContact;
    private String customerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_customer);

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextContact = findViewById(R.id.editTextContact);
        Button buttonUpdate = findViewById(R.id.buttonUpdate);

        // Get customer ID from intent
        customerId = getIntent().getStringExtra("customer_id");

        // Fetch customer data
        fetchCustomerData();

        // Set the update button click listener
        buttonUpdate.setOnClickListener(view -> updateCustomer());
    }

    private void fetchCustomerData() {
        String url = "http://10.159.247.233/electricbillapp/get_customer.php"; // Update with your PHP script URL

        // Create a JSON object request to fetch customer data
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url + "?customer_id=" + customerId, null,
                response -> {
                    try {
                        // Parse the response
                        editTextName.setText(response.getString("customer_name"));
                        editTextAddress.setText(response.getString("customer_address"));
                        editTextContact.setText(response.getString("customer_contact"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(UpdateCustomerActivity.this, "Error parsing customer data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(UpdateCustomerActivity.this, "Error fetching customer data", Toast.LENGTH_SHORT).show());

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }

    private void updateCustomer() {
        // Validate input fields
        if (editTextName.getText().toString().isEmpty() || 
            editTextAddress.getText().toString().isEmpty() || 
            editTextContact.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "http://10.159.247.233/electricbillapp/update_customer.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    // Handle response from the server
                    Toast.makeText(UpdateCustomerActivity.this, response, Toast.LENGTH_SHORT).show();
                    finish(); // Close the activity after update
                },
                error -> Toast.makeText(UpdateCustomerActivity.this, "Error updating customer", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("customer_id", customerId);
                params.put("customer_name", editTextName.getText().toString());
                params.put("customer_address", editTextAddress.getText().toString());
                params.put("customer_contact", editTextContact.getText().toString());
                return params;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);
    }
}
