package com.example.electricbillapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class UpdateAdminActivity extends AppCompatActivity {

    private EditText editTextName, editTextEmail;
    private Button buttonUpdate, buttonBack;
    private String adminId;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_admin);

        editTextName = findViewById(R.id.editTextAdminName);
        editTextEmail = findViewById(R.id.editTextAdminEmail);
        buttonUpdate = findViewById(R.id.buttonUpdateAdmin);
        buttonBack = findViewById(R.id.buttonBackToChiefAdmin);

        // Get the admin ID from the intent
        adminId = getIntent().getStringExtra("admin_id");

        // Pre-fill the fields with the admin's existing details
        loadAdminDetails();

        buttonUpdate.setOnClickListener(view -> updateAdminDetails());

        buttonBack.setOnClickListener(view -> {
            Intent intent = new Intent(UpdateAdminActivity.this, ChiefAdminActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void loadAdminDetails() {
        String url = "http://10.159.247.233/electricbillapp/get_admin_details.php?admin_id=" + adminId;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject admin = new JSONObject(response);
                        String name = admin.getString("admin_name");
                        String email = admin.getString("admin_email");

                        // Populate the text fields with the admin details
                        editTextName.setText(name);
                        editTextEmail.setText(email);

                    } catch (JSONException e) {
                        Toast.makeText(this, "Error parsing admin details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Failed to load admin details: " + error.getMessage(), Toast.LENGTH_SHORT).show());

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    private void updateAdminDetails() {
        String name = editTextName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();

        if (!validateInputs(name, email)) {
            return;
        }

        String url = "http://10.159.247.233/electricbillapp/update_admin.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(this, "Admin updated successfully!", Toast.LENGTH_SHORT).show();
                    // Navigate to ChiefAdminActivity after successful update
                    Intent intent = new Intent(UpdateAdminActivity.this, ChiefAdminActivity.class);
                    startActivity(intent);
                    finish();
                },
                error -> Toast.makeText(this, "Failed to update admin: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("admin_id", adminId);
                params.put("admin_name", name);
                params.put("admin_email", email);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    private boolean validateInputs(String name, String email) {
        if (name.isEmpty()) {
            Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (email.isEmpty()) {
            Toast.makeText(this, "Email cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}