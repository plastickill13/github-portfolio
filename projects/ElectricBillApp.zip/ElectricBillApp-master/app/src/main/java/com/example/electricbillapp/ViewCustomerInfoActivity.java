package com.example.electricbillapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent; // Import Intent
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewCustomerInfoActivity extends AppCompatActivity {

    private TableLayout tableLayout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_customer_info);

        // Initialize TableLayout
        tableLayout = findViewById(R.id.table_layout1);
        tableLayout.setBackgroundColor(getResources().getColor(android.R.color.white));

        // Fetch data from PHP script
        fetchCustomerData();

        // Add button
        Button btnAddCustomer = findViewById(R.id.btnAddCustomer);
        btnAddCustomer.setOnClickListener(view -> {
            Intent intent = new Intent(this, AddCustomerActivity.class);
            startActivity(intent);
            finish();
        });

        // Back button
        Button buttonBack = findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(view -> {
            Intent intent = new Intent(ViewCustomerInfoActivity.this, ChiefAdminActivity.class);
            startActivity(intent);
            finish();
        });
    }

    // Fetch data from PHP script
    private void fetchCustomerData() {
        String url = "http://10.159.247.233/electricbillapp/view_customer.php";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Add data rows
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject customer = response.getJSONObject(i);
                                TableRow dataRow = new TableRow(ViewCustomerInfoActivity.this);

                                // Set alternating background color
                                if (i % 2 == 0) {
                                    dataRow.setBackgroundColor(getResources().getColor(android.R.color.white));
                                } else {
                                    dataRow.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
                                }

                                dataRow.addView(createTextView(customer.getString("customer_id")));
                                dataRow.addView(createTextView(customer.getString("customer_name")));
                                dataRow.addView(createTextView(customer.getString("customer_address")));
                                dataRow.addView(createTextView(customer.getString("customer_contact")));

                                // Set long click listener for the row
                                dataRow.setOnLongClickListener(view -> {
                                    try {
                                        showUpdateDialog(customer.getString("customer_id"),
                                                customer.getString("customer_name"));
                                    } catch (JSONException e) {
                                        throw new RuntimeException(e);
                                    }
                                    return true; // Indicate that the long click was handled
                                });

                                tableLayout.addView(dataRow);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewCustomerInfoActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                });
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16); // Add padding for better appearance
        return textView;
    }

    // Method to show the UpdateCustomerActivity
    private void showUpdateDialog(String customerId, String customerName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Customer Details");
        builder.setMessage("Do you want to update the details for " + customerName + "?");

        builder.setPositiveButton("Yes", (dialog, which) -> {
            // Start UpdateCustomerActivity
            Intent intent = new Intent(ViewCustomerInfoActivity.this, UpdateCustomerActivity.class);
            intent.putExtra("customer_id", customerId); // Pass customer ID to the new activity
            intent.putExtra("customer_name", customerName); // Pass customer name to the new activity
            startActivity(intent); // Start the update activity
            finish();
        });

        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
